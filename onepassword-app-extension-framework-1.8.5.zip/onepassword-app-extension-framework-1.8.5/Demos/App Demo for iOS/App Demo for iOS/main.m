//
//  main.m
//  App Demo for iOS
//
//  Created by Rad Azzouz on 2014-07-14.
//  Copyright (c) 2014 AgileBits. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
	}
}
