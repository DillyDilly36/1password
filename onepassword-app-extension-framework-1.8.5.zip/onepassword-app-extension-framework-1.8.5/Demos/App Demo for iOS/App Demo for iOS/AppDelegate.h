//
//  AppDelegate.h
//  App Demo for iOS
//
//  Created by Rad Azzouz on 2014-07-14.
//  Copyright (c) 2014 AgileBits. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

