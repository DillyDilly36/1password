//
//  ChangePasswordViewController.h
//  App Demo for iOS
//
//  Created by Rad Azzouz on 2014-08-11.
//  Copyright (c) 2014 AgileBits. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChangePasswordViewController : UIViewController

@end
