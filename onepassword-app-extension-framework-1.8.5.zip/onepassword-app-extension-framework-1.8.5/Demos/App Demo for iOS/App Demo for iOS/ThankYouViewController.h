//
//  ThankYouViewController.h
//  App Demo for iOS
//
//  Created by Rad Azzouz on 2014-07-21.
//  Copyright (c) 2014 AgileBits. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThankYouViewController : UIViewController

@end
